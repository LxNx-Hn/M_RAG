# 출력과 편집 안내

M_RAG_A1_PURPLE_PROOFREAD_PRINT.pdf: 글꼴 포함 벡터 PDF, A1세로 출력용
M_RAG_A1_PURPLE_PROOFREAD_EDITABLE.pptx: 편집 원본, 네이티브 표7개와 차트2개
M_RAG_A1_PURPLE_PROOFREAD_EDITABLE.svg: 글꼴 포함 벡터 원본
PREVIEW.png, 300DPI.png, MOCKUP.jpg: 미리보기, 고해상도 이미지, 디지털 배치 목업
assets/: 구조도와 RAG-Cube의 SVG/PDF, 평가 및 결과 PDF, 논문 사본, 수치와 저장 입출력 증거, 참고문헌
qa/B1_PREVIOUS_NEW_COMPARE.png: B1, 이전WORDING A1, 새 교정본을 같은 높이로 비교
A1_PURPLE_PROOFREAD_REVIEW_KO.md: 교정 내용, 원문 근거, 검수와 확인 범위

인쇄는 PDF, 내용 변경은 PPTX 사용
출력 배율100%, 세로 방향, 템플릿 실제 크기593.99×840.98mm
표의 내용을 늘리면 행 높이와 다음 설명 간격을 함께 확인
차트의 평균과 신뢰구간 양 끝점을 함께 편집하며, 세로 좌표1과2는 배치용 값
PPTX에서 맑은 고딕이 없는 환경은 글꼴 대체 가능
Microsoft PowerPoint 직접 실행과 실제 인쇄 검수는 미수행

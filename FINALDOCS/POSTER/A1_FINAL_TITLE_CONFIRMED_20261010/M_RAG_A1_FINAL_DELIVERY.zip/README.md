# M-RAG A1 연구 포스터 — 제목 유지 및 본문 교정

**확정 제목:** 한국어 질의–영어 학술·기술 문서 RAG에서의 HyDE·CAD·SCD 조합 실험

제목을 유지하고 연구 배경, 기술 설명, 평가 조건, 실제 사례와 결론의 표현을 교정하였다. 최신 교정 내역은 ACADEMIC_POLISH_CHANGES.json에 기록하였다. 결과 수치를 유지하고 글자 크기와 배치를 조정하였다. 본문은 18pt, 주요 참고문헌은 16pt로 확대하였다. 전체 참고문헌 22편과 출력 사례는 동봉 파일에 보존하였다. 공개본의 학번은 생략하고 개인정보가 있는 제출본은 로컬에 별도로 보관한다.

- [A1 인쇄 PDF](M_RAG_A1_FINAL_PRINT.pdf)
- [편집용 PPTX](M_RAG_A1_FINAL_EDITABLE.pptx)
- [SVG 원본](M_RAG_A1_FINAL_EDITABLE.svg)
- [PNG 미리보기](M_RAG_A1_FINAL_PREVIEW.png)
- [300dpi 인쇄 이미지](M_RAG_A1_FINAL_300DPI.png)
- [목업](M_RAG_A1_FINAL_MOCKUP.jpg)
- [전체 ZIP](M_RAG_A1_FINAL_DELIVERY.zip)
- [교정 기록](A1_FINAL_REVIEW_KO.md)
- [정확한 A→B 매핑](A1_COPYEDIT_MAP.json)
- [최신 A→C 교정](ACADEMIC_POLISH_CHANGES.json)
- [실물 및 구조 검증](ACADEMIC_POLISH_VALIDATION.json)
- [추가 수정용 프롬프트](POSTER_REVISION_PROMPT_KO.md)

A1 크기는 약 594 × 841mm이다.
